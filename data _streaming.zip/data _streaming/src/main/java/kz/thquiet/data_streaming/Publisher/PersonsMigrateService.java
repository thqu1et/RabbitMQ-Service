package kz.thquiet.data_streaming.Publisher;

import kz.thquiet.data_streaming.Publisher.rabbit.MessageSender;
import kz.thquiet.data_streaming.dto.PersonsDTO;
import kz.thquiet.data_streaming.entity.PersonsEntity;
import kz.thquiet.data_streaming.mapper.PersonsMapper;
import kz.thquiet.data_streaming.repository.MigrationJDBCRepository;
import org.apache.tomcat.util.buf.StringUtils;
import org.springframework.transaction.annotation.Transactional;
import kz.thquiet.data_streaming.dto.ConditionSelectDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class PersonsMigrateService implements MigrationService {

    private static final String SELECT = "SELECT t.*  FROM persons t ";
    private static final String ORDER_BY = " ORDER BY t.inis_taxperson_id asc , t.version_id asc";

    private final MigrationJDBCRepository<PersonsEntity> migrationJdbcRepository;
    private final PersonsMapper personsMapper;
    private final MessageSender messageSender;

    @Override
    public void collectAndSend(int limit, int offset) {
        log.debug("Start collection PersonDto data");
        try (Stream<PersonsEntity> taxpayerNameAudStream = migrationJdbcRepository.findAllStream(SELECT, PersonsEntity.class, limit, offset)) {
            taxpayerNameAudStream
                    .forEach(this::process);
        }
    }

    @Override
    public void collectByConditionAndSend(ConditionSelectDto conditionSelectDto) {
        log.debug("Start collection by condition TaxpayerNameAud data");
        String query = SELECT +
                " WHERE t." + conditionSelectDto.getColumnName() + " IN (" + StringUtils.join(conditionSelectDto.getValues(), ",") + ")";
        try (Stream<PersonsEntity> taxpayerNameAudStream = migrationJdbcRepository.findByConditionStream(query, PersonsEntity.class)) {
            taxpayerNameAudStream
                    .forEach(this::process);
        }
    }

    @Override
    public void collectLatestUpdatesAndSend(String psaModifiedDate) {

    }

    @Override
    public void collectLatestUpdatesAndSendWithPagination(String psaModifiedDate, int limit, int offset) {

    }

    private void process(PersonsEntity migrationTaxpayerNameAud) {
        PersonsDTO personsDTO = personsMapper.entity2Dto(migrationTaxpayerNameAud);
        messageSender.sendMessage(personsDTO);
        log.debug("PersonsEntity with data {} successfully sent", personsDTO);
    }
}
