package kz.thquiet.data_streaming.Publisher.rabbit;

import kz.thquiet.data_streaming.config.RabbitConfiguration;
import kz.thquiet.data_streaming.dto.PersonsDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class MessageSender {

    @Value("${migration.rabbitmq.producer.enabled:false}")
    private boolean RABBITMQ_PRODUCER_ENABLE;

    @Value("${rabbit.queue.name}")
    private String jsonQueueName;

    private final RabbitTemplate rabbitTemplate;

    public void sendMessage(String queueName, Object dto) {
        log.debug("Sending message...");
        if (RABBITMQ_PRODUCER_ENABLE) {
            rabbitTemplate.invoke(operations -> {
                operations.convertAndSend(RabbitConfiguration.EXCHANGE_NAME, queueName, dto);
                return null;
            });
        } else {
            log.warn("Message produce is disabled! Please enable before sending!");
        }
    }

    public void sendMessage(PersonsDTO personsDTO) {
        sendMessage(jsonQueueName, personsDTO);
    }

}
