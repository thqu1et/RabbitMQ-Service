package kz.thquiet.data_streaming.repository;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.stream.Stream;

import static kz.thquiet.data_streaming.Publisher.MigrationService.LIMIT_OFFSET;

@Repository
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@RequiredArgsConstructor
public class MigrationJDBCRepository<MigrationEntity> {

    private final JdbcTemplate jdbcTemplate;

    public Stream<MigrationEntity> findAllStream(String query, Class<MigrationEntity> migrationEntityClass, int limit, int offset) {
        return jdbcTemplate.query(query + LIMIT_OFFSET, new BeanPropertyRowMapper<>(migrationEntityClass), limit, offset).stream();
    }

    public Stream<MigrationEntity> findByConditionStream(String query, Class<MigrationEntity> migrationEntityClass) {
        return jdbcTemplate.query(query, new BeanPropertyRowMapper<>(migrationEntityClass)).stream();
    }
}
