package kz.thquiet.data_streaming.mapper;

import kz.thquiet.data_streaming.dto.PersonsDTO;
import kz.thquiet.data_streaming.entity.PersonsEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PersonsMapper {
    PersonsDTO entity2Dto(PersonsEntity entity);
}
