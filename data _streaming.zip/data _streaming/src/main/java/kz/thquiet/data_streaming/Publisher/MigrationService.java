package kz.thquiet.data_streaming.Publisher;

import kz.thquiet.data_streaming.dto.ConditionSelectDto;

public interface MigrationService {
    String LIMIT_OFFSET = " LIMIT ? OFFSET ?";
    void collectAndSend(int limit, int offset);
    void collectByConditionAndSend(ConditionSelectDto conditionSelectDto);
    void collectLatestUpdatesAndSend(String psaModifiedDate);
    void collectLatestUpdatesAndSendWithPagination(String psaModifiedDate, int limit, int offset);
}
