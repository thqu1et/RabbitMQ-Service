package kz.thquiet.data_streaming.consumer;

import kz.thquiet.data_streaming.Publisher.RabbitMQProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQConsumer {

    private static final Logger LOGGER = LoggerFactory.getLogger(RabbitMQConsumer.class);

    @RabbitListener(queues = {"${queue.name}"})
    public void consume(String Message) {
        LOGGER.info(String.format("Received Message: %s", Message));
    }
}
