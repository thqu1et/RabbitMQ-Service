package kz.thquiet.data_streaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataStreamingApplicationTests {

    @Test
    void contextLoads() {
    }

}
